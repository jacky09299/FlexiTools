# This module will contain functions for processing MP4 files.
#
# Required External Libraries:
# - OpenCV (cv2): pip install opencv-python
# - MoviePy: pip install moviepy
# - Tkinter (usually included with Python)

import tkinter as tk
from tkinter import filedialog, ttk
from rembg import remove
from PIL import Image
from main import Module
import os
import cv2 # For _process_to_frames
from moviepy.editor import (
    VideoFileClip, AudioFileClip, CompositeAudioClip, CompositeVideoClip,
    concatenate_videoclips, concatenate_audioclips, ColorClip
) # For audio extraction, splitting and merging
from rembg import remove # For background removal
import numpy as np # For background removal
import traceback
import threading

class MP4Processor(Module):
    def __init__(self, parent, shared_state, module_name, gui_manager):
        super().__init__(parent, shared_state, module_name, gui_manager)
        self.parent = parent # For thread-safe UI updates
        self.input_path_var = tk.StringVar()
        self.output_path_var = tk.StringVar()
        self.input_type_var = tk.StringVar(value="file")
        self.processing_mode_var = tk.StringVar()

        self.fps_var = tk.StringVar(value='30')
        self.segments_to_save_var = tk.StringVar()

        # For Merge Media
        self.merge_output_filename_var = tk.StringVar(value="merged_output.mp4")
        self.merge_file_list = []

        # Mapping for processing modes
        self.processing_options_keys = [
            "module_mp4_mode_frames",
            "module_mp4_mode_mp3",
            "module_mp4_mode_ogg",
            "module_mp4_mode_split",
            "module_mp4_mode_removebg",
            "module_mp4_mode_merge"
        ]
        self.mode_key_map = {
            "Convert to Frames": "module_mp4_mode_frames",
            "Extract to MP3": "module_mp4_mode_mp3",
            "Extract to OGG": "module_mp4_mode_ogg",
            "Split MP4": "module_mp4_mode_split",
            "Remove Background": "module_mp4_mode_removebg",
            "Merge Media": "module_mp4_mode_merge"
        }
        # Initialize reverse map
        self.reverse_mode_map = {}

        self.create_ui()

    def _log_status_safe(self, message):
        # This method is thread-safe for updating the GUI from a worker thread.
        self.parent.after(0, self._log_status, message)

    def _log_status(self, message):
        # This method should only be called from the main GUI thread.
        self.status_text.config(state=tk.NORMAL)
        self.status_text.insert(tk.END, message + "\n")
        self.status_text.see(tk.END) # Scroll to the end
        self.status_text.update_idletasks() # Ensure UI updates
        self.status_text.config(state=tk.DISABLED)
        self.shared_state.log(message, "INFO")

    def _browse_input(self):
        current_input_type = self.input_type_var.get()
        path = ""
        if current_input_type == "file":
            path = filedialog.askopenfilename(
                title="Select MP4 File",
                filetypes=(("MP4 files", "*.mp4"), ("All files", "*.*" ))
            )
        elif current_input_type == "folder":
            path = filedialog.askdirectory(title="Select Folder Containing MP4 Files")

        if path:
            self.input_path_var.set(path)
            self.input_path_label.config(text=path)
            self._log_status(f"Input path set to: {path}")

    def _browse_output(self):
        path = filedialog.askdirectory(title="Select Output Folder")
        if path:
            self.output_path_var.set(path)
            self.output_path_label.config(text=path)
            self._log_status(f"Output path set to: {path}")

    def _on_processing_mode_changed(self, event=None):
        selected_mode_display = self.processing_mode_var.get()

        # Map display string back to internal key for logic
        selected_mode_key = self.reverse_mode_map.get(selected_mode_display)

        # Fallback logic if mapping fails (e.g. initialization)
        if not selected_mode_key:
             # Try to find key by checking if selected_mode matches any default English string
             for k, v in self.mode_key_map.items():
                 if k == selected_mode_display:
                     selected_mode_key = v
                     break

        for widget in self.dynamic_options_frame.winfo_children():
            widget.pack_forget()

        if selected_mode_key == "module_mp4_mode_frames":
            self.frames_options_frame.pack(fill=tk.X, expand=True)
        elif selected_mode_key == "module_mp4_mode_split":
            self.split_options_frame.pack(fill=tk.X, expand=True)
        elif selected_mode_key == "module_mp4_mode_merge":
            self.merge_options_frame.pack(fill=tk.BOTH, expand=True)

    def _merge_add_files(self):
        files = filedialog.askopenfilenames(
            title="Select Media Files to Merge",
            filetypes=(
                ("Media Files", "*.mp4 *.mov *.avi *.mkv *.mp3 *.wav *.ogg"),
                ("Video Files", "*.mp4 *.mov *.avi *.mkv"),
                ("Audio Files", "*.mp3 *.wav *.ogg"),
                ("All files", "*.*" )
            )
        )
        if files:
            for f in files:
                self.merge_file_list.append(f)
                self.merge_listbox.insert(tk.END, os.path.basename(f))
            self._log_status(f"Added {len(files)} files to merge list.")

    def _merge_remove_selected(self):
        selected_indices = self.merge_listbox.curselection()
        if not selected_indices:
            return
        idx = selected_indices[0]
        self.merge_listbox.delete(idx)
        removed_file = self.merge_file_list.pop(idx)
        self._log_status(f"Removed '{os.path.basename(removed_file)}' from merge list.")

    def _merge_remove_all(self):
        self.merge_listbox.delete(0, tk.END)
        self.merge_file_list.clear()
        self._log_status("Removed all files from merge list.")

    def _merge_move_up(self):
        selected_indices = self.merge_listbox.curselection()
        if not selected_indices:
            return
        idx = selected_indices[0]
        if idx > 0:
            text = self.merge_listbox.get(idx)
            self.merge_listbox.delete(idx)
            self.merge_listbox.insert(idx - 1, text)
            self.merge_listbox.selection_set(idx - 1)
            item = self.merge_file_list.pop(idx)
            self.merge_file_list.insert(idx - 1, item)

    def _merge_move_down(self):
        selected_indices = self.merge_listbox.curselection()
        if not selected_indices:
            return
        idx = selected_indices[0]
        if idx < self.merge_listbox.size() - 1:
            text = self.merge_listbox.get(idx)
            self.merge_listbox.delete(idx)
            self.merge_listbox.insert(idx + 1, text)
            self.merge_listbox.selection_set(idx + 1)
            item = self.merge_file_list.pop(idx)
            self.merge_file_list.insert(idx + 1, item)

    def _parse_time(self, time_str):
        parts = str(time_str).split(':')
        try:
            if len(parts) == 1:
                return int(parts[0])
            elif len(parts) == 2:
                return int(parts[0]) * 60 + int(parts[1])
            elif len(parts) == 3:
                return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
            else:
                raise ValueError(f"Invalid time format structure: {time_str}")
        except ValueError as e:
            raise ValueError(f"Invalid time component in '{time_str}': {e}")

    def _process_to_frames(self, video_path, output_dir, target_fps_str, remove_bg):
        self._log_status_safe(f"Starting 'Convert to Frames' for: {video_path}")
        cap = None
        try:
            try:
                target_fps = int(float(target_fps_str))
            except Exception:
                self._log_status_safe(f"Invalid FPS value: {target_fps_str}, fallback to 1")
                target_fps = 1

            video_filename = os.path.splitext(os.path.basename(video_path))[0]
            frames_output_subdir = os.path.join(output_dir, f"{video_filename}_frames_fps{target_fps}")
            if not os.path.exists(frames_output_subdir):
                os.makedirs(frames_output_subdir)
                self._log_status_safe(f"Created frames output subdirectory: {frames_output_subdir}")
            self._log_status_safe(f"Frame output directory (copy & paste in Explorer): {os.path.abspath(frames_output_subdir)}")
        except Exception as e:
            self._log_status_safe(f"Error creating output subdirectory: {e}")
            return False

        try:
            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                self._log_status_safe(f"Error: Could not open video file {video_path} with OpenCV.")
                return False

            original_fps = cap.get(cv2.CAP_PROP_FPS)
            self._log_status_safe(f"Original video FPS: {original_fps:.2f}")

            if original_fps <= 0 or target_fps <= 0:
                self._log_status_safe(f"Warning: FPS invalid (original: {original_fps}, target: {target_fps}). Will save every frame.")
                frame_interval = 1
            else:
                frame_interval = max(1, int(round(original_fps / target_fps)))

            self._log_status_safe(f"Saving 1 frame every {frame_interval} original frames to achieve ~{target_fps} FPS.")

            if remove_bg:
                self._log_status_safe("Background removal enabled.")

            count = 0
            saved_frame_count = 0
            while True:
                ret, frame = cap.read()
                if not ret:
                    self._log_status_safe(f"End of video or cannot read frame at count {count}.")
                    break
                if count % frame_interval == 0:
                    if remove_bg:
                        frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                        pil_img = Image.fromarray(frame_rgb)
                        output_pil_img = remove(pil_img)
                        frame = cv2.cvtColor(np.array(output_pil_img), cv2.COLOR_RGB2BGR)

                    frame_filename = os.path.join(frames_output_subdir, f"frame_{saved_frame_count:05d}.png")
                    success = cv2.imwrite(frame_filename, frame)
                    if not success:
                        self._log_status_safe(f"Failed to write frame: {frame_filename}")
                    saved_frame_count += 1
                    if saved_frame_count % max(1, target_fps) == 0:
                        self._log_status_safe(f"Saved {saved_frame_count} frames...")
                count += 1

            self._log_status_safe(f"Successfully extracted {saved_frame_count} frames to {frames_output_subdir}")
            if saved_frame_count > 0:
                sample_files = [os.path.join(frames_output_subdir, f) for f in sorted(os.listdir(frames_output_subdir))[:5]]
                self._log_status_safe(f"Sample frame files: {sample_files}")
            return saved_frame_count > 0
        except cv2.error as e_cv2:
            self._log_status_safe(f"OpenCV Error during frame extraction: {e_cv2}")
            return False
        except Exception as e:
            self._log_status_safe(f"General Error during frame extraction: {e}")
            return False
        finally:
            if cap and cap.isOpened():
                cap.release()

    def _process_to_mp3(self, video_path, output_dir):
        self._log_status_safe(f"Starting 'Extract to MP3' for: {video_path}")
        video_clip = None
        audio_clip = None
        try:
            video_filename_no_ext = os.path.splitext(os.path.basename(video_path))[0]
            output_mp3_path = os.path.join(output_dir, f"{video_filename_no_ext}.mp3")

            video_clip = VideoFileClip(video_path)
            if not video_clip.audio:
                self._log_status_safe(f"Error: No audio track found in {video_path}")
                return False

            audio_clip = video_clip.audio
            audio_clip.write_audiofile(output_mp3_path, codec='mp3', logger=None)

            self._log_status_safe(f"Successfully extracted MP3 to: {output_mp3_path}")
            return True
        except Exception as e:
            self._log_status_safe(f"Error during MP3 extraction: {e}")
            return False
        finally:
            if audio_clip: audio_clip.close()
            if video_clip: video_clip.close()

    def _process_to_ogg(self, video_path, output_dir):
        self._log_status_safe(f"Starting 'Extract to OGG' for: {video_path}")
        video_clip = None
        audio_clip = None
        try:
            video_filename_no_ext = os.path.splitext(os.path.basename(video_path))[0]
            output_ogg_path = os.path.join(output_dir, f"{video_filename_no_ext}.ogg")

            video_clip = VideoFileClip(video_path)
            if not video_clip.audio:
                self._log_status_safe(f"Error: No audio track found in {video_path}")
                return False

            audio_clip = video_clip.audio
            audio_clip.write_audiofile(output_ogg_path, codec='libvorbis', logger=None)

            self._log_status_safe(f"Successfully extracted OGG to: {output_ogg_path}")
            return True
        except Exception as e:
            self._log_status_safe(f"Error during OGG extraction: {e}")
            return False
        finally:
            if audio_clip: audio_clip.close()
            if video_clip: video_clip.close()

    def _process_remove_background(self, video_path, output_dir):
        self._log_status_safe(f"Starting 'Remove Background' for: {video_path}")
        cap = None
        out = None
        try:
            video_filename_no_ext = os.path.splitext(os.path.basename(video_path))[0]
            output_video_path = os.path.join(output_dir, f"{video_filename_no_ext}_no_bg.mp4")

            cap = cv2.VideoCapture(video_path)
            if not cap.isOpened():
                self._log_status_safe(f"Error: Could not open video file {video_path} with OpenCV.")
                return False

            width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
            height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
            fps = cap.get(cv2.CAP_PROP_FPS)
            if fps <= 0:
                fps = 30.0

            fourcc = cv2.VideoWriter_fourcc(*'mp4v')
            out = cv2.VideoWriter(output_video_path, fourcc, fps, (width, height))

            frame_count = 0
            while cap.isOpened():
                ret, frame = cap.read()
                if not ret:
                    break

                frame_rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                result = remove(frame_rgb)
                if result.shape[2] == 4:
                    result_bgr = cv2.cvtColor(np.array(result), cv2.COLOR_RGBA2BGR)
                else:
                    result_bgr = cv2.cvtColor(np.array(result), cv2.COLOR_RGB2BGR)
                out.write(result_bgr)

                frame_count += 1
                if frame_count % int(fps) == 0:
                    self._log_status_safe(f"Processed {frame_count} frames...")

            self._log_status_safe(f"Successfully removed background and saved to: {output_video_path}")
            return True
        except Exception as e:
            self._log_status_safe(f"Error during background removal: {e}")
            return False
        finally:
            if cap: cap.release()
            if out: out.release()
            cv2.destroyAllWindows()

    def _process_split_mp4(self, video_path, output_dir, split_points_str, segments_to_save_str):
        self._log_status_safe(f"Starting 'Split MP4' for: {video_path}")
        main_video_clip = None
        subclip = None

        try:
            parsed_split_points = []
            time_pairs = split_points_str.split(',')
            for i, pair_str in enumerate(time_pairs):
                pair_str = pair_str.strip()
                if not pair_str: continue
                start_str, end_str = pair_str.split('-')
                start_sec = self._parse_time(start_str.strip())
                end_sec = self._parse_time(end_str.strip())
                if start_sec >= end_sec:
                    self._log_status_safe(f"Warning: Invalid range {pair_str} (start >= end), skipping segment {i+1}.")
                    continue
                parsed_split_points.append((start_sec, end_sec))

            if not parsed_split_points:
                self._log_status_safe("Error: No valid split points found after parsing. Check format and values.")
                return False
            self._log_status_safe(f"Parsed split points (seconds): {parsed_split_points}")

            segments_to_save_indices = []
            if segments_to_save_str.strip():
                try:
                    segments_to_save_indices = [int(s.strip()) -1 for s in segments_to_save_str.split(',') if s.strip()]
                    self._log_status_safe(f"Will save specific segments (0-indexed): {segments_to_save_indices}")
                except ValueError:
                    self._log_status_safe("Error: Invalid format for 'Segments to Save'. Use comma-separated numbers (e.g., 1,3).")
                    return False
            else:
                self._log_status_safe("No specific segments selected, will attempt to save all parsed segments.")

            video_filename_no_ext = os.path.splitext(os.path.basename(video_path))[0]
            all_segments_successful = True

            main_video_clip = VideoFileClip(video_path)
            duration = main_video_clip.duration

            for i, (start_sec, end_sec) in enumerate(parsed_split_points):
                subclip = None
                if start_sec >= duration:
                    self._log_status_safe(f"Warning: Start time {start_sec}s for segment {i+1} is beyond video duration ({duration}s). Skipping.")
                    continue
                end_sec = min(end_sec, duration)

                if not segments_to_save_indices or i in segments_to_save_indices:
                    self._log_status_safe(f"Processing segment {i+1}: {start_sec}s - {end_sec}s")
                    output_filename = os.path.join(output_dir, f"{video_filename_no_ext}_part{i+1}.mp4")
                    try:
                        subclip = main_video_clip.subclip(start_sec, end_sec)
                        subclip.write_videofile(output_filename, codec="libx264", audio_codec="aac", logger=None)
                        self._log_status_safe(f"Saved segment {i+1} to {output_filename}")
                    except Exception as e_subclip:
                        self._log_status_safe(f"Error processing or writing subclip for segment {i+1} ({start_sec}s-{end_sec}s): {e_subclip}")
                        all_segments_successful = False
                    finally:
                        if subclip: subclip.close()
                else:
                    self._log_status_safe(f"Skipping segment {i+1} as it's not in the list of segments to save.")

            if all_segments_successful:
                 self._log_status_safe("Finished splitting MP4 successfully for all selected/valid segments.")
            else:
                 self._log_status_safe("Finished splitting MP4 with some errors for one or more segments.")
            return all_segments_successful
        except ValueError as ve:
            self._log_status_safe(f"Error parsing input values for splitting: {ve}")
            return False
        except Exception as e:
            self._log_status_safe(f"An error occurred during splitting setup or main video loading: {e}")
            return False
        finally:
            if main_video_clip: main_video_clip.close()

    def _try_fast_concat(self, file_list, output_path, is_audio_only):
        try:
            import imageio_ffmpeg
            import subprocess
            import tempfile
            ffmpeg_exe = imageio_ffmpeg.get_ffmpeg_exe()
            
            if not file_list:
                return False
                
            first_ext = os.path.splitext(file_list[0])[1].lower()
            for f in file_list:
                if os.path.splitext(f)[1].lower() != first_ext:
                    self._log_status_safe("Fast concat check failed: Files have different extensions.")
                    return False
            
            if not is_audio_only:
                target_size = None
                target_fps = None
                for f in file_list:
                    try:
                        with VideoFileClip(f) as clip:
                            if not clip.size or not clip.fps:
                                self._log_status_safe(f"Fast concat check failed: Could not determine size/fps for {os.path.basename(f)}")
                                return False
                            if target_size is None:
                                target_size = clip.size
                                target_fps = clip.fps
                            else:
                                if target_size != clip.size:
                                    self._log_status_safe(f"Fast concat check failed: Size mismatch. {target_size} vs {clip.size}")
                                    return False
                                if abs(target_fps - clip.fps) > 1.0:
                                    self._log_status_safe(f"Fast concat check failed: FPS mismatch. {target_fps} vs {clip.fps}")
                                    return False
                    except Exception as e:
                        self._log_status_safe(f"Fast concat check failed: Could not read {f}. Error: {e}")
                        return False

            if output_path.lower().endswith('.wav'):
                self._log_status_safe("Attempting fast ffmpeg concat (re-encoding for WAV to preserve headers)...")
            else:
                self._log_status_safe("Attempting fast ffmpeg concat (stream copy)...")
            
            with tempfile.NamedTemporaryFile(mode='w', suffix='.txt', delete=False, encoding='utf-8') as f:
                list_file_path = f.name
                for media_file in file_list:
                    safe_path = os.path.abspath(media_file).replace('\\', '/')
                    safe_path = safe_path.replace("'", "'\\''")
                    f.write(f"file '{safe_path}'\n")
            
            cmd = [
                ffmpeg_exe,
                '-y',
                '-f', 'concat',
                '-safe', '0',
                '-i', list_file_path
            ]
            
            if not output_path.lower().endswith('.wav'):
                cmd.extend(['-c', 'copy'])
                
            cmd.append(output_path)
            
            result = subprocess.run(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
            
            try:
                os.remove(list_file_path)
            except Exception:
                pass
            
            if result.returncode == 0:
                self._log_status_safe("Fast concat successful!")
                return True
            else:
                self._log_status_safe(f"Fast concat failed. Exit code {result.returncode}.")
                if os.path.exists(output_path):
                    try:
                        os.remove(output_path)
                    except Exception:
                        pass
                return False
                
        except ImportError:
            self._log_status_safe("imageio_ffmpeg not found. Skipped fast concat.")
            return False
        except Exception as e:
            self._log_status_safe(f"Fast concat exception: {e}")
            return False

    def _process_merge_media(self, file_list, output_path):
        self._log_status_safe("Starting 'Merge Media' process...")
        is_audio_only = all(f.lower().endswith(('.mp3', '.wav', '.ogg', '.m4a', '.flac')) for f in file_list)

        if is_audio_only:
            self._log_status_safe("All files appear to be audio. Performing audio-only merge.")
            return self._merge_audio_files(file_list, output_path)
        else:
            self._log_status_safe("Video file(s) detected. Performing video/mixed-media merge.")
            return self._merge_video_files(file_list, output_path)

    def _merge_audio_files(self, file_list, output_path):
        if not output_path.lower().endswith(('.mp3', '.wav', '.ogg')):
            output_path += ".mp3"
            self._log_status_safe(f"Output filename adjusted for audio: {output_path}")

        if self._try_fast_concat(file_list, output_path, is_audio_only=True):
            return True

        self._log_status_safe("Falling back to slow audio merge method...")
        clips = []
        final_clip = None
        try:
            self._log_status_safe(f"Output audio file will be: {output_path}")
            for i, file_path in enumerate(file_list):
                self._log_status_safe(f"Loading audio file {i+1}/{len(file_list)}: {os.path.basename(file_path)}")
                try:
                    clips.append(AudioFileClip(file_path))
                except Exception as e:
                    self._log_status_safe(f"Could not load audio file {os.path.basename(file_path)}. Skipping. Error: {e}")

            if not clips:
                self._log_status_safe("No valid audio clips to merge.")
                return False

            final_clip = concatenate_audioclips(clips)

            self._log_status_safe("Concatenation complete. Writing to audio file...")
            final_clip.write_audiofile(output_path, logger=None)

            self._log_status_safe(f"Successfully merged audio to: {output_path}")
            return True
        except Exception as e:
            self._log_status_safe(f"An error occurred during audio merge: {e}")
            self._log_status_safe(traceback.format_exc())
            return False
        finally:
            self._log_status_safe("Cleaning up audio resources...")
            for clip in clips:
                try:
                    clip.close()
                except Exception: pass
            if final_clip:
                try:
                    final_clip.close()
                except Exception: pass

    def _merge_video_files(self, file_list, output_path):
        if self._try_fast_concat(file_list, output_path, is_audio_only=False):
            return True

        self._log_status_safe("Falling back to slow video merge method...")
        self._log_status_safe(f"Output video file will be: {output_path}")
        clips = []
        final_clip = None
        target_size = None
        target_fps = 24

        try:
            for file_path in file_list:
                try:
                    with VideoFileClip(file_path) as clip:
                        if clip.size and clip.fps:
                            target_size = clip.size
                            target_fps = clip.fps
                            self._log_status_safe(f"Using resolution {target_size} and FPS {target_fps:.2f} from '{os.path.basename(file_path)}' as target.")
                            break
                except Exception:
                    continue

            if not target_size:
                self._log_status_safe("Error: Could not determine a target resolution. Please include at least one standard video file.")
                return False

            for i, file_path in enumerate(file_list):
                self._log_status_safe(f"Processing file {i+1}/{len(file_list)}: {os.path.basename(file_path)}")
                clip = None
                try:
                    clip = VideoFileClip(file_path, target_resolution=(target_size[1], target_size[0]), resize_algorithm='bicubic')
                    if clip.fps is None: clip.fps = target_fps
                    if clip.size != target_size:
                        clip = clip.resize(target_size)
                    clips.append(clip)
                except Exception:
                    if clip: clip.close()
                    try:
                        audio_clip = AudioFileClip(file_path)
                        video_from_audio = ColorClip(size=target_size, color=(0,0,0), duration=audio_clip.duration).set_audio(audio_clip)
                        video_from_audio.fps = target_fps
                        clips.append(video_from_audio)
                        self._log_status_safe(f"Treated '{os.path.basename(file_path)}' as audio on a black background.")
                    except Exception as e_audio:
                        self._log_status_safe(f"Failed to process '{os.path.basename(file_path)}'. Skipping. Error: {e_audio}")

            if not clips:
                self._log_status_safe("Error: No valid clips could be created.")
                return False

            self._log_status_safe("Concatenating clips...")
            final_clip = concatenate_videoclips(clips, method="compose")

            self._log_status_safe("Writing final video file...")
            final_clip.write_videofile(output_path, codec="libx264", audio_codec="aac", threads=4, logger=None)

            self._log_status_safe(f"Successfully merged video to: {output_path}")
            return True
        except Exception as e:
            self._log_status_safe(f"An error occurred during video merge: {e}")
            self._log_status_safe(traceback.format_exc())
            return False
        finally:
            self._log_status_safe("Cleaning up video resources...")
            for clip in clips:
                try:
                    clip.close()
                except Exception: pass
            if final_clip:
                try:
                    final_clip.close()
                except Exception: pass

    def _start_processing(self):
        self.process_button.config(state=tk.DISABLED)
        self.status_text.config(state=tk.NORMAL)
        self.status_text.delete("1.0", tk.END)
        self.status_text.config(state=tk.DISABLED)

        processing_thread = threading.Thread(target=self._processing_worker)
        processing_thread.daemon = True
        processing_thread.start()

    def _processing_worker(self):
        self._log_status_safe("--- Starting processing ---")
        try:
            input_val = self.input_path_var.get()
            output_dir = self.output_path_var.get()

            # Get internal key for mode
            mode_display = self.processing_mode_var.get()
            mode = self.reverse_mode_map.get(mode_display, self.mode_key_map.get("Convert to Frames"))

            if not output_dir:
                self._log_status_safe("Error: Output directory must be selected.")
                return
            if not os.path.isdir(output_dir):
                try:
                    os.makedirs(output_dir, exist_ok=True)
                    self._log_status_safe(f"Created output directory: {output_dir}")
                except Exception as e:
                    self._log_status_safe(f"Error: Could not create output directory {output_dir}: {e}")
                    return

            self._log_status_safe(f"Mode selected: {mode_display}")

            if mode == "module_mp4_mode_merge":
                files_to_merge = self.merge_file_list
                if not files_to_merge or len(files_to_merge) < 2:
                    self._log_status_safe("Error: Please add at least two files to merge.")
                    return
                output_filename = self.merge_output_filename_var.get()
                if not output_filename:
                    self._log_status_safe("Error: Output filename cannot be empty.")
                    return
                output_path = os.path.join(output_dir, output_filename)
                success = self._process_merge_media(files_to_merge, output_path)
                if success:
                    self._log_status_safe("--- Media merging finished successfully. ---")
                else:
                    self._log_status_safe("--- Media merging finished with errors. Please check logs. ---")
                return

            if not input_val:
                self._log_status_safe("Error: Input path must be selected for this mode.")
                return
            if not os.path.exists(input_val):
                self._log_status_safe(f"Error: Input path does not exist: {input_val}")
                return

            if mode == "module_mp4_mode_frames":
                fps_str = self.fps_var.get()
                try:
                    if int(fps_str) <= 0:
                        self._log_status_safe("Error: FPS must be a positive number.")
                        return
                except ValueError:
                    self._log_status_safe("Error: Invalid FPS value. Must be a number.")
                    return
            elif mode == "module_mp4_mode_split":
                if not self.split_points_text.get("1.0", tk.END).strip():
                    self._log_status_safe("Error: Split points cannot be empty for Split MP4 mode.")
                    return

            files_to_process = []
            if self.input_type_var.get() == "file":
                files_to_process.append(input_val)
            else:
                if os.path.isdir(input_val):
                    files_to_process.extend([os.path.join(input_val, i) for i in os.listdir(input_val) if i.lower().endswith(".mp4")])
                    if not files_to_process:
                        self._log_status_safe(f"No MP4 files found in folder: {input_val}")
                        return
                else:
                    self._log_status_safe(f"Error: Input folder not found: {input_val}")
                    return

            all_files_processed_successfully = True
            for video_path in files_to_process:
                self._log_status_safe(f"--- Processing file: {video_path} ---")
                current_file_success = False
                if mode == "module_mp4_mode_frames":
                    current_file_success = self._process_to_frames(video_path, output_dir, self.fps_var.get(), self.remove_bg_var.get())
                elif mode == "module_mp4_mode_mp3":
                    current_file_success = self._process_to_mp3(video_path, output_dir)
                elif mode == "module_mp4_mode_ogg":
                    current_file_success = self._process_to_ogg(video_path, output_dir)
                elif mode == "module_mp4_mode_removebg":
                    current_file_success = self._process_remove_background(video_path, output_dir)
                elif mode == "module_mp4_mode_split":
                    current_file_success = self._process_split_mp4(video_path, output_dir, self.split_points_text.get("1.0", tk.END).strip(), self.segments_to_save_var.get())
                else:
                    self._log_status_safe(f"Error: Unknown processing mode: {mode}")
                    current_file_success = False

                if not current_file_success:
                    all_files_processed_successfully = False
                    self._log_status_safe(f"Failed to process {video_path} in {mode_display} mode.")
                else:
                    self._log_status_safe(f"Successfully processed {video_path} in {mode_display} mode.")

            if all_files_processed_successfully:
                self._log_status_safe("--- All processing finished successfully. ---")
            else:
                self._log_status_safe("--- Processing finished with one or more errors. Please check logs. ---")

        except Exception as e:
            self._log_status_safe(f"Critical error in processing orchestrator: {e}")
            self._log_status_safe(traceback.format_exc())
        finally:
            self.parent.after(0, lambda: self.process_button.config(state=tk.NORMAL))

    def create_ui(self):
        content_frame = self.get_frame()

        # Keep references for update_language
        self.input_frame = ttk.LabelFrame(content_frame, text="Input Selection", padding=(10, 5))
        self.input_frame.pack(fill=tk.X, padx=5, pady=5)

        input_type_rb_frame = ttk.Frame(self.input_frame)
        input_type_rb_frame.pack(fill=tk.X)
        self.rb_single = ttk.Radiobutton(input_type_rb_frame, text="Single File", variable=self.input_type_var, value="file")
        self.rb_single.pack(side=tk.LEFT, padx=5, pady=2)
        self.rb_folder = ttk.Radiobutton(input_type_rb_frame, text="Folder", variable=self.input_type_var, value="folder")
        self.rb_folder.pack(side=tk.LEFT, padx=5, pady=2)

        input_path_frame = ttk.Frame(self.input_frame)
        input_path_frame.pack(fill=tk.X, pady=(5,0))
        self.btn_browse_input = ttk.Button(input_path_frame, text="Browse Input", command=self._browse_input)
        self.btn_browse_input.pack(side=tk.LEFT, padx=5)
        self.input_path_label = ttk.Label(input_path_frame, text="No input selected (not used for Merge)", anchor=tk.W, relief=tk.SUNKEN, padding=(2,2))
        self.input_path_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)

        self.output_frame = ttk.LabelFrame(content_frame, text="Output Location", padding=(10, 5))
        self.output_frame.pack(fill=tk.X, padx=5, pady=5)

        output_path_browse_frame = ttk.Frame(self.output_frame)
        output_path_browse_frame.pack(fill=tk.X)
        self.btn_browse_output = ttk.Button(output_path_browse_frame, text="Browse Output", command=self._browse_output)
        self.btn_browse_output.pack(side=tk.LEFT, padx=5)
        self.output_path_label = ttk.Label(output_path_browse_frame, text="No output location selected", anchor=tk.W, relief=tk.SUNKEN, padding=(2,2))
        self.output_path_label.pack(side=tk.LEFT, fill=tk.X, expand=True, padx=5)

        self.options_frame = ttk.LabelFrame(content_frame, text="Processing Options", padding=(10, 5))
        self.options_frame.pack(fill=tk.X, padx=5, pady=5)
        self.lbl_mode = ttk.Label(self.options_frame, text="Mode:")
        self.lbl_mode.pack(side=tk.LEFT, padx=(0,5), pady=5)

        self.processing_mode_combobox = ttk.Combobox(self.options_frame, textvariable=self.processing_mode_var, state="readonly")
        self.processing_mode_combobox.pack(fill=tk.X, expand=True, padx=5, pady=5)
        self.processing_mode_combobox.bind("<<ComboboxSelected>>", self._on_processing_mode_changed)

        self.dynamic_options_frame = ttk.Frame(content_frame, padding=(5,5))
        self.dynamic_options_frame.pack(fill=tk.BOTH, expand=True, padx=5, pady=(0,5))

        # Frames Options
        self.frames_options_frame = ttk.Frame(self.dynamic_options_frame)
        self.lbl_fps = ttk.Label(self.frames_options_frame, text="Target FPS:")
        self.lbl_fps.pack(side=tk.LEFT, padx=(0,5))
        self.fps_entry = ttk.Entry(self.frames_options_frame, textvariable=self.fps_var, width=5)
        self.fps_entry.pack(side=tk.LEFT)
        self.remove_bg_var = tk.BooleanVar()
        self.check_remove_bg = ttk.Checkbutton(self.frames_options_frame, text="Remove Background", variable=self.remove_bg_var)
        self.check_remove_bg.pack(side=tk.LEFT, padx=5)

        # Split Options
        self.split_options_frame = ttk.Frame(self.dynamic_options_frame)
        split_points_label_frame = ttk.Frame(self.split_options_frame)
        split_points_label_frame.pack(fill=tk.X, pady=(0,2))
        self.lbl_split_points = ttk.Label(split_points_label_frame, text="Split Points (e.g., 0:10-0:20, 0:30-0:45):")
        self.lbl_split_points.pack(side=tk.LEFT)
        self.split_points_text = tk.Text(self.split_options_frame, height=3, relief=tk.SUNKEN, borderwidth=1)
        self.split_points_text.pack(fill=tk.X, pady=(0,5))
        segments_to_save_frame = ttk.Frame(self.split_options_frame)
        segments_to_save_frame.pack(fill=tk.X)
        self.lbl_segments = ttk.Label(segments_to_save_frame, text="Segments to Save (e.g., 1,3 or blank for all):")
        self.lbl_segments.pack(side=tk.LEFT, padx=(0,5))
        self.segments_to_save_entry = ttk.Entry(segments_to_save_frame, textvariable=self.segments_to_save_var)
        self.segments_to_save_entry.pack(fill=tk.X, expand=True)

        # Merge Options
        self.merge_options_frame = ttk.Frame(self.dynamic_options_frame)
        self.list_frame = ttk.LabelFrame(self.merge_options_frame, text="Files to Merge (in order)", padding=(10, 5))
        self.list_frame.pack(fill=tk.BOTH, expand=True, pady=5)
        self.merge_listbox = tk.Listbox(self.list_frame, selectmode=tk.SINGLE, height=6)
        self.merge_listbox.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar = ttk.Scrollbar(self.list_frame, orient=tk.VERTICAL, command=self.merge_listbox.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.merge_listbox.config(yscrollcommand=scrollbar.set)

        button_frame = ttk.Frame(self.merge_options_frame)
        button_frame.pack(fill=tk.X, pady=5)
        self.btn_add_files = ttk.Button(button_frame, text="Add Files...", command=self._merge_add_files)
        self.btn_add_files.pack(side=tk.LEFT, padx=2)
        self.btn_remove_sel = ttk.Button(button_frame, text="Remove Selected", command=self._merge_remove_selected)
        self.btn_remove_sel.pack(side=tk.LEFT, padx=2)
        self.btn_remove_all = ttk.Button(button_frame, text="Remove All", command=self._merge_remove_all)
        self.btn_remove_all.pack(side=tk.LEFT, padx=2)
        self.btn_up = ttk.Button(button_frame, text="Move Up", command=self._merge_move_up)
        self.btn_up.pack(side=tk.LEFT, padx=2)
        self.btn_down = ttk.Button(button_frame, text="Move Down", command=self._merge_move_down)
        self.btn_down.pack(side=tk.LEFT, padx=2)

        output_name_frame = ttk.Frame(self.merge_options_frame)
        output_name_frame.pack(fill=tk.X, pady=(5,0))
        self.lbl_out_filename = ttk.Label(output_name_frame, text="Output Filename:")
        self.lbl_out_filename.pack(side=tk.LEFT, padx=(0, 5))
        ttk.Entry(output_name_frame, textvariable=self.merge_output_filename_var).pack(fill=tk.X, expand=True)

        self.process_button = ttk.Button(content_frame, text="Start Processing", command=self._start_processing)
        self.process_button.pack(pady=10)

        status_label_frame = ttk.Frame(content_frame)
        status_label_frame.pack(fill=tk.X, padx=5, pady=(5,0))
        self.lbl_status = ttk.Label(status_label_frame, text="Status:")
        self.lbl_status.pack(anchor=tk.W)
        self.status_text = tk.Text(content_frame, height=5, state=tk.DISABLED, relief=tk.SUNKEN, borderwidth=1)
        self.status_text.pack(fill=tk.BOTH, expand=True, padx=5, pady=(0,5))

        self.update_language()
        self._on_processing_mode_changed()
        self.shared_state.log(f"MP4Processor UI fully created for module: {self.module_name}", "INFO")

    def update_language(self):
        super().update_language()
        if not getattr(self, 'input_frame', None): return

        self.input_frame.config(text=self.tr("module_mp4_grp_input", "Input Selection"))
        self.rb_single.config(text=self.tr("module_mp4_rb_single", "Single File"))
        self.rb_folder.config(text=self.tr("module_mp4_rb_folder", "Folder"))
        self.btn_browse_input.config(text=self.tr("module_mp4_btn_browse_in", "Browse Input"))
        if "No input selected" in self.input_path_label.cget("text") or "未選擇" in self.input_path_label.cget("text"):
             self.input_path_label.config(text=self.tr("module_mp4_lbl_no_input", "No input selected"))

        self.output_frame.config(text=self.tr("module_mp4_grp_output", "Output Location"))
        self.btn_browse_output.config(text=self.tr("module_mp4_btn_browse_out", "Browse Output"))
        if "No output" in self.output_path_label.cget("text") or "未選擇" in self.output_path_label.cget("text"):
             self.output_path_label.config(text=self.tr("module_mp4_lbl_no_output", "No output location selected"))

        self.options_frame.config(text=self.tr("module_mp4_grp_options", "Processing Options"))
        self.lbl_mode.config(text=self.tr("module_mp4_lbl_mode", "Mode:"))

        # Update combobox values while preserving selection mapping
        current_key = self.reverse_mode_map.get(self.processing_mode_var.get())

        translated_options = []
        self.reverse_mode_map = {} # Rebuild map

        for key in self.processing_options_keys:
            translated = self.tr(key)
            translated_options.append(translated)
            self.reverse_mode_map[translated] = key

        self.processing_mode_combobox['values'] = translated_options

        if current_key:
            # Try to set display value for current key
            self.processing_mode_var.set(self.tr(current_key))
        elif not self.processing_mode_var.get():
             self.processing_mode_combobox.current(0)

        self.lbl_fps.config(text=self.tr("module_mp4_lbl_fps", "Target FPS:"))
        self.check_remove_bg.config(text=self.tr("module_mp4_chk_removebg", "Remove Background"))

        self.lbl_split_points.config(text=self.tr("module_mp4_lbl_split_points", "Split Points (e.g., 0:10-0:20):"))
        self.lbl_segments.config(text=self.tr("module_mp4_lbl_segments", "Segments to Save (e.g., 1,3):"))

        self.list_frame.config(text=self.tr("module_mp4_grp_merge_files", "Files to Merge (in order)"))
        self.btn_add_files.config(text=self.tr("module_mp4_btn_add_files", "Add Files..."))
        self.btn_remove_sel.config(text=self.tr("module_mp4_btn_remove_sel", "Remove Selected"))
        self.btn_remove_all.config(text=self.tr("module_mp4_btn_remove_all", "Remove All"))
        self.btn_up.config(text=self.tr("module_mp4_btn_up", "Move Up"))
        self.btn_down.config(text=self.tr("module_mp4_btn_down", "Move Down"))
        self.lbl_out_filename.config(text=self.tr("module_mp4_lbl_out_filename", "Output Filename:"))

        self.process_button.config(text=self.tr("module_mp4_btn_start", "Start Processing"))
        self.lbl_status.config(text=self.tr("module_mp4_lbl_status", "Status:"))
